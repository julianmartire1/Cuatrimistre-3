<?php

require_once "Usuario.php";
function verificar(){
$band=0;
$leer = fopen("usuarios.txt","r");
$array = [];

while(!feof($leer))
{
    $archivoAux = fgets($leer);
    $usuario = explode(" - ",$archivoAux);
    $usuario[0] = trim($usuario[0]);


    if($usuario[0] != "")
    {
        $array[] = new Usuario($usuario[0],$usuario[1],$usuario[2],$usuario[3]);
    }
}




fclose($leer);

$email=$_POST["txtEmail"];
$clave=$_POST["txtClave"];


foreach ($array as $item) {
  $itemE=$item->getEmail();
  $itemC=$item->getClave();

  if( $itemE== $email && $itemC==$clave)
  {
    $band=1;
  }



}

return $array;
}

include "Listado.php";

 ?>
