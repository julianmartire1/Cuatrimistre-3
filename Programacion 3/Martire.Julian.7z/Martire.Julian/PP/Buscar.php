<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>buscar</title>
  </head>
  <body>
    <form action="VerificarUsuario.php" method="post" enctype="multipart/form-data">

    
    Email:<br/><input type='text' name='txtEmail'/>
    <br/>
    Clave:<br/><input type='text' name='txtClave'/>
    <br/>

    <input type='submit' name='Buscar'/>
    </form>
  </body>
</html>
