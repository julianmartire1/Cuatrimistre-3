<?php

    $resultado = FALSE;

    $usuario=$_POST["txtNombre"]." - ".$_POST["txtEmail"]." - ".$_POST["txtClave"]." - ".$_POST["txtEdad"]."\r\n";

    $archivo = fopen("usuarios.txt","a");
    $escribo = fwrite($archivo,$usuario);

    if($escribo > 0)
    {
        $resultado = TRUE;
        echo "Archivo guardado";
        echo "<br/><a href='index.php'>Volver Inicio</a>";
    }
    else {
      echo "No se pudo guardar el archivo";
    }

    fclose($archivo);




 ?>
