<?php

require_once "VerificarUsuario.php";

$array=verificar();

if(count($array) > 0)
{
    echo '<table style="text-align:center;" class="egt">

            <tr>

                <th>Nombre</th>

                <th>Email</th>

                <th>Edad</th>

                <th>Clave</th>
            </tr>';
        foreach ($array as $index)
        {
            echo "<tr>

                    <td>".$index->getNombre()."</td>

                    <td>".$index->getEmail()."</td>

                    <td>".$index->getEdad()."</td>

                    <td>".$index->getClave()."</td>";
        }

            echo "</table>";
}

 ?>
