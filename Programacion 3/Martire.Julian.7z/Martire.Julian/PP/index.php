<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>PP</title>
  </head>
  <body>
    <form action="UsuarioCarga.php" method="post" enctype="multipart/form-data">
    Nombre:<br/><input type="text" name="txtNombre"/>
    <br/>
    Email:<br/><input type="text" name="txtEmail"/>
    <br/>
    Edad:<br/><input type="text" name="txtEdad"/>
    <br/>
    Clave:<br/><input type="text" name="txtClave"/>
    <br/>
    <input type="submit" name="Enviar"/>



    </form>
    <a href='Buscar.php'>Buscar Usuario</a>
  </body>
</html>
