
<?php


try {

  $numero=$_POST["txtNumero"];
  $desc=$_POST["txtDesc"];
  $pais=$_POST["txtPais"];
  $archivo=$_FILES["archivo"]["name"];

  $pdo=new PDO("mysql:dbname=pp_prog_III","root","");
  $band=$pdo->prepare("INSERT INTO `containers`(`numero`, `descripcion`, `pais`, `foto`)
  VALUES (:numero),(:descripcion),(:pais),(:foto)");

  $band->bindParam(":titel",$numero);
  $band->bindParam(":descripcion",$desc);
  $band->bindParam(":pais",$pais);
  $band->bindParam(":foto",$archivo);


  $band->execute();
  /*$band=$pdo->prepare("INSERT INTO `cds`(`titel`) VALUES (?)");

  $band->bindParam(1,$nombre);
  $band->execute();*/



/*INSERT INTO `containers`(`numero`, `descripcion`, `pais`, `foto`)
VALUES ([value-1],[value-2],[value-3],[value-4])*/



  //$band=$pdo->query("SELECT * FROM cds");

  //FETCHALL
  /*$rr=$band->fetch(PDO::FETCH);
  var_dump($rr);*/
  //FETCHASSOC
  /*
  $rr=$band->fetch(PDO::FETCHASSOC);
  while ($fila = mysql_fetch_assoc($resultado)){
  echo $fila["titel"];
      echo $fila["interpret"];
      echo $fila["jahr"];

    }*/



} catch (PDOException $e) {
  echo $e->getMessage();
}

 ?>
