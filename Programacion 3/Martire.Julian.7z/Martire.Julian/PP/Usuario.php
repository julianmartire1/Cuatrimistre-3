<?php

/**
 *
 */
class usuario
{
  private $_nombre;
  private $_email;
  private $_edad;
  private $_clave;
  function __construct($nombre,$email,$clave,$edad)
  {
    $this->_nombre=$nombre;
    $this->_email=$email;
    $this->_edad=$edad;
    $this->_clave=$clave;
  }

  function getEdad()
  {
      return $this->_edad;
  }

  function getClave()
  {
      return $this->_clave;
  }

  function getNombre()
  {
      return $this->_nombre;
  }

  function getEmail()
  {
      return $this->_email;
  }
}


 ?>
