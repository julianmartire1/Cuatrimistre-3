<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>PP</title>
  </head>
  <body>
    <form action="ContainerAlta.php" method="post" enctype="multipart/form-data">
    Nombre:<br/><input type="text" name="txtNumero"/>
    <br/>
    Email:<br/><input type="text" name="txtDesc"/>
    <br/>
    Edad:<br/><input type="text" name="txtPais"/>
    <br/>
    <input type="file" name="archivo"/>
    <br/>

    <input type="submit" name="Enviar"/>



    </form>
  </body>
</html>
